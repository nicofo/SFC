#!/usr/bin/env python

import sys




# input comes from STDIN (standard input)
for line in sys.stdin:
	# remove leading and trailing whitespace
	line = line.strip()
	# split the line into words
	words = line.split(',')

	year = words[0]
	origin = words[16]
	cancelled = words[21] #En cas de ser 1 la casella 22 es el motiu
	depDelay = words[15] # Retraso del Dep

	print  '%s,%s\t%s-%s'% (year, origin, cancelled, depDelay)